package com.ecommerce.api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CommerceApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
